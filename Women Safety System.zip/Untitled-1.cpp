#include <WiFi.h>
#include <HTTPClient.h>
#include <TinyGPS++.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define BUTTON 12
#define LED 2
#define BUZZER 15

#define GPS_RX 4
#define GPS_TX 5

#define SIM_RX 16
#define SIM_TX 17

LiquidCrystal_I2C lcd(0x27,16,2);

TinyGPSPlus gps;

HardwareSerial gpsSerial(2);
HardwareSerial sim800(1);

const char* ssid = "ME";
const char* password = "12341234";

String server = "http://10.153.91.220:5000";

String phone = "+916363163085";

float lat = 0;
float lon = 0;

unsigned long pressStart = 0;
bool buttonHeld = false;

void setup()
{

Serial.begin(115200);

pinMode(BUTTON, INPUT_PULLUP);
pinMode(LED, OUTPUT);
pinMode(BUZZER, OUTPUT);

gpsSerial.begin(9600, SERIAL_8N1, GPS_RX, GPS_TX);
sim800.begin(9600, SERIAL_8N1, SIM_RX, SIM_TX);

Wire.begin(21,22);

lcd.init();
lcd.backlight();

lcd.setCursor(0,0);
lcd.print("Women Safety");

lcd.setCursor(0,1);
lcd.print("Connecting WiFi");

WiFi.begin(ssid,password);

while(WiFi.status()!=WL_CONNECTED)
{
delay(500);
}

lcd.clear();
lcd.setCursor(0,0);
lcd.print("WiFi Connected");

delay(2000);

}

void loop()
{

while(gpsSerial.available())
{
gps.encode(gpsSerial.read());
}

if(gps.location.isUpdated())
{
lat = gps.location.lat();
lon = gps.location.lng();
}

handleButton();

}

void handleButton()
{

if(digitalRead(BUTTON)==LOW)
{

if(!buttonHeld)
{
pressStart = millis();
buttonHeld = true;
}

}

else
{

if(buttonHeld)
{

unsigned long pressTime = millis() - pressStart;

if(pressTime > 2000)
{
triggerSOS();
}

buttonHeld = false;

}

}

}

void triggerSOS()
{

lcd.clear();
lcd.setCursor(0,0);
lcd.print("SOS ACTIVATED");

for(int i=0;i<6;i++)
{

digitalWrite(LED,HIGH);
digitalWrite(BUZZER,HIGH);

delay(300);

digitalWrite(LED,LOW);
digitalWrite(BUZZER,LOW);

delay(300);

}

sendSMS();
sendToServer();

}

void sendSMS()
{

String message = "HELP! I am in danger\n";

message += "Location:\nhttps://maps.google.com/?q=";

message += String(lat,6);
message += ",";
message += String(lon,6);

sim800.println("AT+CMGF=1");
delay(1000);

sim800.print("AT+CMGS=\"");
sim800.print(phone);
sim800.println("\"");

delay(1000);

sim800.print(message);

delay(500);

sim800.write(26);

lcd.clear();
lcd.setCursor(0,0);
lcd.print("SMS SENT");

}

void sendToServer()
{

if(WiFi.status()==WL_CONNECTED)
{

HTTPClient http;

String url = server + "/sos?device=WS01&lat=" + String(lat,6) + "&lon=" + String(lon,6);

http.begin(url);

int code = http.GET();

http.end();

lcd.clear();
lcd.setCursor(0,0);
lcd.print("Server Updated");

}

}